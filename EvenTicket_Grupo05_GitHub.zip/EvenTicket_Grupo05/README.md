# EvenTicket — Grupo 05

Projeto da Unidade 3 da disciplina **Requisitos, Modelagem e Análise de Dados** (2026/2), Prof. Edson Vaz Lopes.

## Equipe
Beatriz Yumi M. Hara, Camila Brandão de Sá, Gabriel Felipe Xavier, Pedro Gazzolla, Enzo e Emanuel.

## Cenário
Uma produtora precisa controlar eventos, locais, participantes e inscrições, respeitando capacidade e evitando duplicidade. O projeto se limita à **modelagem conceitual e lógica**, sem implementação executável do banco.

## Navegação
Todos os documentos estão na pasta [`04-dados/`](04-dados/), numerados de `00` a `06`. Os diagramas `02` e `04` têm versões PDF (extraídas dos slides apresentados pelo grupo) e `.drawio` (reconstruções editáveis para continuidade do trabalho).

## Atenção à revisão do grupo
Estes arquivos são uma **consolidação proposta** a partir do edital, slides e entrega individual do Enzo; precisam ser revisados pela equipe antes da entrega. Em especial, confirmar o tratamento de reinscrição após cancelamento, as restrições previstas e os ajustes de notação do DER. Nenhuma restrição foi implementada ou testada em banco de dados.

## Entregas
Repositório: 20/11/2026; defesa individual: 27/11/2026; relatório final no Teams: 02/12/2026.
