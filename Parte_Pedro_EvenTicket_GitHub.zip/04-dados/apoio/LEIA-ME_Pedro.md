# Parte de Pedro — instruções de integração

O PDF individual `Entrega_Pedro_Gazzolla.pdf` registra a contribuição de Pedro em 06/11/2026.

- `03_decisoes_modelagem_trecho_pedro.md`: trecho para integrar ao `03_decisoes_modelagem.md` coletivo.
- `cardinalidades_pedro.drawio`: reconstrução editável de apoio dos relacionamentos e cardinalidades informados no PDF. **Não substitui** o DER completo `02_modelo_conceitual_v1` do grupo.

Antes de publicar, comparem o trecho e o desenho com o DER coletivo e não substituam arquivos de outros integrantes automaticamente.
