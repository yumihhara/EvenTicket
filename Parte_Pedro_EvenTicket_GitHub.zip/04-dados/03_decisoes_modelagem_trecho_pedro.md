# Contribuição de Pedro Gazzolla — decisões de modelagem

> Trecho de apoio para incorporar ao arquivo coletivo `03_decisoes_modelagem.md`. Baseado na entrega individual de 06/11/2026.

## Categoria
- A entidade `Categoria` possui `id_categoria` (identificador) e `nome`.
- Uma categoria pode classificar zero ou muitos eventos: `Categoria (0,N)`.
- Cada evento pertence obrigatoriamente a uma categoria: `Evento (1,1)`.
- O relacionamento **Classifica** é **1:N**.

## Atividade — entidade fraca
- A entidade `Atividade` representa elementos da programação de um evento, como palestra ou oficina.
- Atributos: `numero_atividade` (identificador parcial), `titulo`, `horario_inicio` e `horario_fim`.
- A atividade é identificada pelo conjunto (`evento.codigo`, `numero_atividade`).
- **Possui** é o relacionamento identificante entre `Evento` e `Atividade`.
- Um evento pode possuir zero ou muitas atividades: `Evento (0,N)`.
- Uma atividade pertence obrigatoriamente a um único evento: `Atividade (1,1)`, participação total.
- Justificativa: uma atividade só faz sentido vinculada ao evento do qual faz parte.

## Cardinalidades e participação

| Relacionamento | Cardinalidade | Participação do primeiro lado | Participação do segundo lado |
|---|---|---|---|
| Sedia (`Local`–`Evento`) | 1:N | Local (0,N) | Evento (1,1), total |
| Classifica (`Categoria`–`Evento`) | 1:N | Categoria (0,N) | Evento (1,1), total |
| Possui (`Evento`–`Atividade`) | 1:N | Evento (0,N) | Atividade (1,1), total |
| Inscrição (`Participante`–`Evento`) | N:N | Participante (0,N) | Evento (0,N) |

**Observação:** o DER completo e os arquivos de entrega obrigatórios são coletivos. Este é um trecho da contribuição de Pedro, não um oitavo item exigido pelo edital.
