# Parte de Pedro Gazzolla — EvenTicket

Esta pasta reúne a entrega individual (PDF original) e material de apoio para incorporar ao projeto coletivo no GitHub.

O professor solicita um repositório por grupo, com os sete arquivos obrigatórios dentro de `04-dados/`. Não criem uma entrega separada por integrante. A versão editável aqui é um desenho complementar das cardinalidades, e não deve substituir o DER completo já construído pela equipe.
